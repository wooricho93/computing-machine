package member;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import book.Action;
import dto.MemberDAO;
import dto.MemberVO;

public class UserManagerFormAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// id값을 가져온다
		String id = request.getParameter("id");
		MemberDAO mDao = MemberDAO.getInstance();

		MemberVO mVo = mDao.getMember(id); //getMember 메서드를 호출해서 입력받은 id값을 VO에 전달
		request.setAttribute("mVo", mVo); 

		RequestDispatcher dis = request.getRequestDispatcher("/member/userManager.jsp");
		dis.forward(request, response);
	}
}