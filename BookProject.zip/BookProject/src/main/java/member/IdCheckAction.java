package member;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import book.Action;
import dto.MemberDAO;

//없어도됨
public class IdCheckAction implements Action {

	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// id중복 체크를 위해 id값을 불러온다
		String id = request.getParameter("id");

		MemberDAO mDao = MemberDAO.getInstance();

		int result = mDao.confirmID(id);

		// id값과 중복결과를 출력
		request.setAttribute("id", id);
		request.setAttribute("result", result);

		request.getRequestDispatcher("/member/idCheck.jsp").forward(request, response);
		new IdCheckAction().execute(request, response);

	}
}