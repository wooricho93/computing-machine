package member;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import book.Action;
import dto.MemberDAO;
import dto.MemberVO;

public class MemberListAction implements Action {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("utf-8"); // 한글 깨짐 방지
		response.setContentType("text/html; charset=utf-8");

		MemberDAO mDao = MemberDAO.getInstance(); // MemberDAO의 객체를 얻어오기 위해 getInstance()를 호출

		List<MemberVO> memberList = mDao.listMember(); // listMember 메소드를 호출하여 List<BookVO>객체에 저장
		request.setAttribute("memberList", memberList); // request객체의 속성에 데이터를 담아 jsp페이지로 보낸다

		System.out.println("작동중" + memberList);

		RequestDispatcher dis = request.getRequestDispatcher("member/memberList.jsp");
		dis.forward(request, response); // memberList.jsp로 포워딩

	}
}