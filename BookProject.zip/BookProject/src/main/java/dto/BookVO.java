package dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BookVO {

	private int num; //순위
	private String category; //카테고리
	private String title; //책이름
	private String price;  //가격
	private String summary;  //줄거리
	private String author; //저자
	private String pub; //출판사
	private String grade;  //평점
	private String pictureurl;
	
}
