package book;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.BookDAO;
import dto.BookVO;

public class BookRegisterAction implements Action { //입력한 게시글 정보를 DB에 추가한다
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//BookVO에서 값을 불러움
		BookVO bVo = new BookVO();

		//불러온 값을 bVo에 저장
		bVo.setCategory(request.getParameter("category"));
		bVo.setTitle(request.getParameter("title"));
		bVo.setPrice(request.getParameter("price"));
		bVo.setSummary(request.getParameter("summary"));
		bVo.setAuthor(request.getParameter("author"));
		bVo.setPub(request.getParameter("pub"));
		bVo.setGrade(request.getParameter("grade"));
		bVo.setPictureurl(request.getParameter("pictureurl"));

		BookDAO Dao = BookDAO.getInstance();
		Dao.insertBook(bVo); //insertBook 메서드를 호출해서 입력받은 VO값을 DB에 전달

		response.sendRedirect("BookServlet?command=book_list"); 
	}
}
