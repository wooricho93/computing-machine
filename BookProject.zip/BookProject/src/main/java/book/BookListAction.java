package book;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.BookDAO;
import dto.BookVO;

public class BookListAction implements Action { //게시글 전체 정보를 DB에서 얻어온다

	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String url = "/book/bookList.jsp";

		BookDAO bDao = BookDAO.getInstance(); // BookDAO의 객체를 얻어오기 위해 getInstance()를 호출

		List<BookVO> booklist = bDao.selectAllBooks(); // selectAllBooks 메소드를 호출하여 List<BookVO>객체에 저장
		request.setAttribute("booklist", booklist); // request객체의 속성에 데이터를 담아 jsp페이지로 보낸다

		RequestDispatcher dis = request.getRequestDispatcher(url); // bookList.jsp로 포워딩
		dis.forward(request, response);
	}

}
