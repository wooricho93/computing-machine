package book;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BookRegisterFormAction implements Action { //새로운 게시글 정보를 입력받기 위한 게시글 등록 페이지로 이동하도록 한다

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String url = "/book/bookRegister.jsp"; 

		RequestDispatcher dispatcher = request.getRequestDispatcher(url); // bookRegister.jsp로 포워딩
		dispatcher.forward(request, response);

	}

}
