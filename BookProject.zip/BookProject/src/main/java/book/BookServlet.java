package book;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BookServlet")
public class BookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public BookServlet() { 
		super();
	}
	//요청을 받아서 요청에 해당하는 Model과 View를 호출하는 역할을 한다
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String command = request.getParameter("command"); 
		System.out.println("BoardServlet 에서 요청 받음을 확인 : " + command); //요청을 서블릿이 받았음을 콘솔 창에서 확인 할 수 있다

		ActionFactory af = ActionFactory.getInstance(); 
		Action action = af.getAction(command); //command 요청 파라미터 값을 af객체의 getAction() 메소드에 전달해준다

		if (action != null) {
			action.execute(request, response); //null이 아닐 경우에만 execute()메소드가 호출 된다
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8"); //한글 깨짐 방지
		doGet(request, response);
	}

}
