package book;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BookMainAction implements Action {
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// bookMain으로 가는 경로 지정
		String url = "/book/bookMain.jsp";

		RequestDispatcher dis = request.getRequestDispatcher(url); // bookMain.jsp로 포워딩
		dis.forward(request, response);
	}
}